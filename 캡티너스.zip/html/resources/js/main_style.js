/* main */
function main_wrap(){
    var win_h = $(window).height();
    $('.main_wrap').height(win_h);
}
$(window).resize(function(){
    main_wrap();
});
$(window).ready(function(){
    main_wrap()
    /* main  scroll */
    var section_1 = $('#section_1').offset().top
    $('.main_wrap').on('mousewheel DOMMouseScroll', function(){
        var win_src = $(window).scrollTop()
        
        if(win_src < 1){
            $('html,body').stop().animate({scrollTop:section_1},500)
        }
    });
    $('.mouse_icon').click(function(){
        $('html,body').stop().animate({scrollTop:section_1},500)
    })
    $(window).scroll(function(){
        var scr = $(window).scrollTop();

         if( scr >= section_1 - 500){
			$('#header').addClass('header_on')
		};
        if( scr <= section_1 - 500){
            $('#header').removeClass('header_on')
            
        };
        if(scr < section_1){
            $('.right_nav').removeClass('right_nav_on');
           
        }
        if(scr >= section_1){
            
             $('.right_nav').addClass('right_nav_on');
        };
        
    });
    $('.condition .button_area').click(function(){
       var btn_on = $(this).hasClass('button_area_on')
        if(btn_on == true){
            $(this).removeClass('button_area_on')
        }else{
            $(this).addClass('button_area_on')
        }
    });
    /*nav*/
    $('.head_nav > ul > li').find('a').click(function(e){
         e.preventDefault();
    })
    $('.head_nav > ul > li').click(function(){
       var this_idx = $(this).index() + 1 ;
        var go_nav = $('#section_'+this_idx).offset().top
        $('html,body').stop().animate({scrollTop:go_nav},500);
    });
    
    
    
	$('.per_pop').click(function(){
		event.preventDefault();
		popup_open();
	});
	//screen.width  : 현재 운영체제의 너비
		//screen.height : 현재 운영체제의 높이
		var w = 633;    //팝업창의 너비
		var h = 510;    //팝업창의 높이
		//중앙위치 구해오기
		var LeftPosition=(screen.width-w)/2;
		var TopPosition=(screen.height-h)/2;
		
		//팝업 호출
		function popup_open() {   
			window.open('http://draft.shaper.kr/gtb_tour/html/personal.html', "aa","width="+w+",height="+h+",top="+TopPosition+",left="+LeftPosition+", scrollbars=yes");
		};
});

	

    // leftmenu
    $(document).ready(function(){
        // menu 클래스 바로 하위에 있는 a 태그를 클릭했을때
        $(".smenu>h3").click(function(){
            var submenu = $(this).next("ul");
 
            // submenu 가 화면상에 보일때는 위로 보드랍게 접고 아니면 아래로 보드랍게 펼치기
            if( submenu.is(":visible") ){
                submenu.slideUp();
            }else{
                submenu.slideDown();
            }
        });
    });


            