/*layout*/
$(window).ready(function(){
    
    var w_h = $(window).height()
    $('.wrap').css({'min-height':w_h})
    $(window).resize(function(){
        var w_h = $(window).height()
        $('.wrap').css({'min-height':w_h})
    })
    $('.select_group .level_1 span').click(function(){
       var slct_on = $(this).next().css('display')
        if(slct_on == 'block'){
            $(this).next().slideUp();
        }else{
            $(this).next().slideDown();
        }
    });
    $('.select_group .level_2 li').click(function(){
        var text_this = $(this).text()

        $(this).parent('.level_2').hide();
        $(this).addClass('select').siblings().removeClass("select");
       
        $(this).parent().parent('.level_1').find('span').text(text_this)
    });
    
});